from distutils.core import setup

setup(
	name=			'find_a_prime',
	version=		'1.0.0',
	py_modules= 	['find_a_prime'],
	author=			'alpha32',
	author_email=	'andrew.neher@gmail.com',
	url=			'http://www.highlylogical.net',
	description=	'just a basic prime number finder.'
	)
